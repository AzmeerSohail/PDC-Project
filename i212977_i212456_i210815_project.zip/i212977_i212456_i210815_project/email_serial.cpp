//Azmeer Sohail (21i-2977)
//Hamza Shahid (21i-0815)
//Talal Habshi (21i-2456)
#include <iostream>
#include <vector>
#include <queue>
#include <limits>
#include <fstream>
#include <sstream>
#include <string>
#include <random>
#include <ctime>
#include <list>
#include <set>
#include <algorithm>
#include <chrono>

#define INF std::numeric_limits<int>::max()

using namespace std;

// Struct to represent a path
struct P { // Define struct P
    int c; // Integer variable to store cost
    vector<int> v; // Vector to store vertices

    P(int c, const vector<int>& v) : c(c), v(v) {} // Constructor to initialize cost and vertices

    bool operator<(const P& o) const { // Overload less than operator
        return c > o.c; // Return true if cost is greater than other's cost
    }
};

// Adjacency list representation of the graph
typedef vector<vector<pair<int, int>>> G; // Define G as a 2D vector of pairs of integers

// Original function: Dijkstra's algorithm
vector<int> dijk(const G& g, int s, int e) { // Function to perform Dijkstra's algorithm
    int n = g.size(); // Get the size of the graph
    vector<int> dist(n, INF); // Initialize distance vector with maximum integer values
    vector<int> prev(n, -1); // Initialize previous vector with -1 values
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq; // Priority queue for min-heap

    dist[s] = 0; // Set the distance of the starting node to 0
    pq.push({0, s}); // Push the starting node to the priority queue

    while (!pq.empty()) { // While the priority queue is not empty
        int u = pq.top().second; // Get the current node from the top of the priority queue
        pq.pop(); // Pop the current node from the priority queue

        if (u == e) break; // If the current node is the destination, exit the loop

        for (const auto& [v, w] : g[u]) { // Iterate over neighbors of the current node
            int alt = dist[u] + w; // Calculate the alternative distance
            if (alt < dist[v]) { // If the alternative distance is less than the current distance
                dist[v] = alt; // Update the distance to the neighbor
                prev[v] = u; // Update the previous node for the neighbor
                pq.push({alt, v}); // Push the neighbor to the priority queue
            }
        }
    }

    vector<int> path; // Initialize the path vector
    int current = e; // Initialize the current node as the destination
    while (current != -1) { // Traverse the previous nodes to reconstruct the path
        path.push_back(current); // Add the current node to the path
        current = prev[current]; // Move to the previous node
    }
    reverse(path.begin(), path.end()); // Reverse the path vector
    return path; // Return the shortest path
}

// Original function: Yen's K-shortest path algorithm
vector<P> sk(const G& g, int s, int d, int k) { // Function to find K shortest paths
    vector<P> sp; // Initialize vector to store shortest paths

    // Find the shortest path from s to d
    vector<int> p = dijk(g, s, d); // Find the shortest path using Dijkstra's algorithm
    if (p.empty()) return {}; // If no path found, return an empty vector

    // Store the shortest path as the first k-shortest path
    sp.push_back(P(p.size() - 1, p)); // Store the cost and vertices of the shortest path

    // Maintain a set of potential k-shortest paths
    set<vector<int>> pp; // Set to store potential paths

    // Iterate k times to find k shortest paths
    for (int i = 1; i < k; ++i) { // Iterate to find K shortest paths
        // Iterate over each node in the current shortest path
        for (int j = 0; j < sp[i - 1].v.size() - 1; ++j) { // Iterate over vertices of the previous shortest path
            int sn = sp[i - 1].v[j]; // Get the spur node from the previous shortest path
            vector<int> rp(sp[i - 1].v.begin(), sp[i - 1].v.begin() + j + 1); // Create the root path

            // Remove the edges that are part of the previous shortest paths
            G mg = g; // Create a copy of the original graph
            for (const auto& p : sp) { // Iterate over previous shortest paths
                if (rp.size() > p.v.size()) continue; // If the root path is longer than the previous path, continue
                if (equal(rp.begin(), rp.end(), p.v.begin())) { // If the root path is a prefix of a previous path
                    int u = p.v[j]; // Get the source vertex of the edge to remove
                    int v = p.v[j + 1]; // Get the destination vertex of the edge to remove
                    auto it = find_if(mg[u].begin(), mg[u].end(), // Find the edge in the graph
                                       [v](const pair<int, int>& p) { return p.first == v; });
                    if (it != mg[u].end()) mg[u].erase(it); // Erase the edge from the graph
                }
            }

            // Calculate the spur path
            vector<int> spath = dijk(mg, sn, d); // Find the shortest path from spur node to destination
            if (!spath.empty()) { // If a spur path is found
                // Concatenate the root path and spur path to get a new path
                vector<int> tp = rp; // Initialize the total path with the root path
                tp.insert(tp.end(), spath.begin() + 1, spath.end()); // Insert the spur path after the root path

                // Add the new path to potential paths
                if (pp.find(tp) == pp.end()) { // If the path is not already in the set
                    pp.insert(tp); // Insert the path into the set
                }
            }
        }

        // Check if potential paths are available
        if (pp.empty()) break; // If no more potential paths available, exit loop

        // Select the minimum cost path from potential paths
        vector<int> np = *pp.begin(); // Get the minimum cost path from the set
        int c = 0; // Initialize the cost of the path
        for (int j = 0; j < np.size() - 1; ++j) { // Iterate over edges of the path
            int u = np[j]; // Get the source vertex of the edge
            int v = np[j + 1]; // Get the destination vertex of the edge
            for (const auto& [n, w] : g[u]) { // Iterate over adjacent vertices of the source vertex
                if (n == v) { // If the adjacent vertex is the destination vertex
                    c += w; // Add the weight of the edge to the total cost
                    break; // Exit the loop
                }
            }
        }

        // Add the new path to shortest paths
        sp.push_back(P(c, np)); // Store the cost and vertices of the new path

        // Remove the selected path from potential paths
        pp.erase(np); // Remove the path from the set of potential paths
    }

    return sp; // Return the vector of K shortest paths
}

// Main function
int main() {
    auto start = chrono::steady_clock::now(); // Measure start time
    int nn; // Number of nodes in the graph
    G g; // Graph data structure

    // Open input file
    ifstream f("Email-EuAll.txt");
    if (!f) { // If failed to open file
        cerr << "Failed to open file" << endl; // Print error message
        exit(1); // Exit program with error code
    }

    string l; // Variable to store each line of the file
    int mn = 0; // Initialize maximum node index to 0
    while (getline(f, l)) { // Read each line of the file
        if (l[0] == '#' || l.empty()) continue; // Skip comments and empty lines
        int s, t; // Variables to store node indices
        istringstream iss(l); // Create a string stream from the line
        if (!(iss >> s >> t)) continue; // Read node indices from the line
        mn = max(mn, max(s, t)); // Update maximum node index
    }

    nn = mn + 1; // Calculate number of nodes
    g.resize(nn); // Resize the graph to accommodate the number of nodes

    // Reset file to read again
    f.clear();
    f.seekg(0, ios::beg);

    while (getline(f, l)) { // Read each line of the file
        if (l[0] == '#' || l.empty()) continue; // Skip comments and empty lines
        int s, t; // Variables to store node indices
        istringstream iss(l); // Create a string stream from the line
        if (!(iss >> s >> t)) continue; // Read node indices from the line
        g[s].push_back({t, 1}); // Add edge from s to t with weight 1
        g[t].push_back({s, 1}); // Add edge from t to s with weight 1 (assuming undirected graph)
    }

    f.close(); // Close the input file

    srand(time(NULL)); // Seed random number generator with current time

    int k = 5; // Number of shortest paths to find

    for (int i = 0; i < 10; i++) { // Perform 10 iterations
        int s = rand() % nn; // Generate random start node index
        int d; // Variable to store the end node index
        do { // Loop until a valid end node is found
            d = rand() % nn; // Generate random end node index
        } while (s == d); // Ensure start and end nodes are different

        cout << "Finding " << k << " shortest paths from " << s << " to " << d << ":\n"; // Print details of the shortest paths to find
        auto r = sk(g, s, d, k); // Find K shortest paths from start to end
        if (r.empty()) { // If no path found
            cout << "No path found\n"; // Print no path found message
        } else { // If paths found
            for (const auto& p : r) { // Iterate over found paths
                cout << "Distance: " << p.c << ", Path: "; // Print path distance
                for (int n : p.v) cout << n << " "; // Print path vertices
                cout << "\n"; // Move to the next line
            }
        }
    }

    auto end = chrono::steady_clock::now(); // Measure end time
    auto diff = end - start; // Calculate time difference
    cout << "Execution time: " << chrono::duration <double>(diff).count() << " seconds" << endl;
 // Print execution time in seconds

    return 0; 
}
