//Azmeer Sohail (21i-2977)
//Hamza Shahid (21i-0815)
//Talal Habshi (21i-2456)
#include <iostream>
#include <vector>
#include <queue>
#include <limits>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <random>
#include <ctime>
#include <algorithm>
#include <set>
#include <chrono>

#define INF std::numeric_limits<int>::max()

using namespace std;

// Structure to represent a path
struct P {
    int c; // Total cost of the path
    vector<int> v; // Vertices forming the path

    // Constructor
    P(int c = 0, const vector<int>& v = {}) : c(c), v(v) {}

    // Overloading '<' operator for comparison
    bool operator<(const P& o) const {
        return c > o.c; // For min-heap priority queue
    }
};

// Define Graph as a vector of vectors of pairs
typedef vector<vector<pair<int, int>>> G; // Alias for graph type

// Original function: Dijkstra's algorithm
pair<int, vector<int>> d(const G& g, int src, int dest) {
    int n = g.size(); // Get the size of the graph
    vector<int> dist(n, INF); // Initialize distance vector with INF
    vector<int> prev(n, -1); // Initialize previous vector with -1
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq; // Initialize priority queue
    dist[src] = 0; // Set distance to source as 0
    pq.push({0, src}); // Push source to priority queue

    // Dijkstra's algorithm
    while (!pq.empty()) {
        int u = pq.top().second; // Get the top vertex from priority queue
        pq.pop(); // Pop the top element
        if (u == dest) break; // If destination is reached, break
        // Iterate over neighbors of current vertex
        for (const auto& [v, weight] : g[u]) {
            int alt = dist[u] + weight; // Calculate alternative distance
            if (alt < dist[v]) {
                dist[v] = alt; // Update distance if alternative is shorter
                prev[v] = u; // Update previous vertex
                pq.push({alt, v}); // Push the updated distance to priority queue
            }
        }
    }
    vector<int> path; // Vector to store the path
    // Reconstruct the shortest path
    for (int at = dest; at != -1; at = prev[at]) {
        path.push_back(at); // Push vertices to path vector
    }
    reverse(path.begin(), path.end()); // Reverse the path
    return {dist[dest], path}; // Return the distance and path
}

// Original function: Yen's K-shortest path algorithm
vector<P> y(const G& g, int src, int dest, int k) {
    vector<P> sp; // Vector to store shortest paths
    auto [bc, bp] = d(g, src, dest); // Get the base cost and path
    if (bp.empty()) return sp; // If base path is empty, return empty vector
    sp.emplace_back(bc, bp); // Push the base cost and path to shortest paths vector
    set<vector<int>> c; // Set to store candidate paths

    // Loop for finding K-shortest paths
    for (int i = 1; i < k; ++i) {
        if (sp.size() < i) continue; // Continue if there are fewer than k shortest paths
        int l = sp[i-1].v.size(); // Get the length of previous shortest path
        // Iterate over vertices of previous shortest path
        for (int j = 0; j < l - 1; ++j) {
            int sn = sp[i-1].v[j]; // Get the spur node
            vector<int> rp(sp[i-1].v.begin(), sp[i-1].v.begin() + j + 1); // Get the root path
            G mg = g;  // Deep copy of the graph
            // Iterate over shortest paths to remove edges
            for (auto& p : sp) {
                if (rp.size() > p.v.size()) continue; // Continue if root path is longer
                // Check if root path matches part of shortest path
                if (equal(rp.begin(), rp.end(), p.v.begin())) {
                    int u = p.v[j], v = p.v[j+1]; // Get the vertices of edge to remove
                    // Remove edge from modified graph
                    mg[u].erase(remove_if(mg[u].begin(), mg[u].end(), [v](const pair<int, int>& e) { return e.first == v; }));
                }
            }
            auto [sc, spath] = d(mg, sn, dest); // Get spur path
            if (!spath.empty() && spath.front() == sn) {
                vector<int> tp = rp; // Temporary path
                tp.insert(tp.end(), spath.begin() + 1, spath.end()); // Concatenate root and spur path
                c.insert(tp); // Insert candidate path to local set
            }
        }
    }

    // Copy candidates to shortest paths vector
    for (const auto& p : c) {
        sp.emplace_back(p.size() - 1, p); // Push candidate path to shortest paths vector
    }
    return sp; // Return shortest paths vector
}

// Main function
int main() {
    G g; // Graph
    map<string, int> nm; // Node map
    vector<string> rnm; // Reverse node map
    int nn = 0; // Number of nodes

    // Read graph from file
    ifstream f("doctorwho.csv"); // Open file
    string l, sn, tn, w, t; // Strings for parsing
    if (!f.is_open()) {
        cerr << "Failed to open the file." << endl; // Error message if file cannot be opened
        return 1; // Return error code
    }
    getline(f, l);  // Discard header
    
    // Parse each line of the file
    while (getline(f, l)) {
        if (l.empty() || l[0] == '#') continue; // Skip empty lines and comments
        stringstream ss(l); // String stream for parsing
        getline(ss, sn, ','); // Get source node
        getline(ss, tn, ','); // Get target node
        getline(ss, w, ','); // Get weight
        getline(ss, t, ','); // Get type

        // Add source node to node map if not already present
        if (nm.find(sn) == nm.end()) {
            nm[sn] = nn; // Assign index to node
            rnm.push_back(sn); // Add node to reverse node map
            nn++; // Increment node count
        }
        // Add target node to node map if not already present
        if (nm.find(tn) == nm.end()) {
            nm[tn] = nn; // Assign index to node
            rnm.push_back(tn); // Add node to reverse node map
            nn++; // Increment node count
        }
        int u = nm[sn]; // Get index of source node
        int v = nm[tn]; // Get index of target node
        int weight = stoi(w); // Convert weight to integer

        // Resize graph if necessary
        if (g.size() <= u) g.resize(u+1);
        if (g.size() <= v) g.resize(v+1);
        g[u].emplace_back(v, weight); // Add edge to graph
        if (t == "undirected") {
            g[v].emplace_back(u, weight); // Add reverse edge if graph is undirected
        }
    }
    f.close(); // Close file

    srand(time(NULL));  // Seed for randomness
    int k = 6;  // Number of shortest paths to find
    int ppp = 10;  // Number of pairs to process
    
    auto start = chrono::steady_clock::now(); // Start measuring execution time

    // Generate random source and destination pairs and find shortest paths
    for (int i = 0; i < ppp; ++i) {
        int src = rand() % nn; // Random source node
        int dest;
        do {
            dest = rand() % nn; // Random destination node (different from source)
        } while (src == dest);
        vector<P> p = y(g, src, dest, k); // Find K-shortest paths
        cout << "Paths from " << rnm[src] << " to " << rnm[dest] << ":" << endl; // Print paths
        for (const P& pth : p) {
            cout << "Cost: " << pth.c << ", Path: "; // Print cost and path
            for (int v : pth.v) cout << rnm[v] << " "; // Print vertices of path
            cout << endl; // Print newline
        }
    }
    
    auto end = chrono::steady_clock::now(); // Measure end time
    auto diff = end - start; // Calculate time difference
    cout << "Execution time: " << chrono::duration <double>(diff).count() << " seconds" << endl;
 // Print execution time in seconds
    return 0; 
}
