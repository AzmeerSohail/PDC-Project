//Azmeer Sohail (21i-2977)
//Hamza Shahid (21i-0815)
//Talal Habshi (21i-2456)
#include <iostream>
#include <vector>
#include <queue>
#include <limits>
#include <fstream>
#include <sstream>
#include <string>
#include <random>
#include <ctime>
#include <list>
#include <set>
#include <algorithm>
#include <mpi.h>
#include <omp.h>

#define MAX_INT std::numeric_limits<int>::max()
using namespace std;

struct P { // Define a structure P
    int cost; // Integer variable to store the cost
    vector<int> vertices; // Vector to store the vertices
    P(int c = 0, const vector<int>& v = {}) : cost(c), vertices(v) {} // Constructor to initialize cost and vertices
    
    bool operator<(const P& other) const { // Overload the less than operator
        return cost > other.cost; // Return true if cost is greater than other's cost
    }
};

typedef vector<vector<pair<int, int>>> G; // Define G as a 2D vector of pairs of integers

pair<int, vector<int>> djks(const G& grph, int start, int end) { // Function to perform Dijkstra's algorithm
    int n = grph.size(); // Get the size of the graph
    vector<int> dist(n, MAX_INT); // Initialize distance vector with maximum integer values
    vector<int> previous(n, -1); // Initialize previous vector with -1 values
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq; // Priority queue for min-heap

    dist[start] = 0; // Set the distance of the starting node to 0
    pq.push({0, start}); // Push the starting node to the priority queue

    while (!pq.empty()) { // While the priority queue is not empty
        int current = pq.top().second; // Get the current node from the top of the priority queue
        pq.pop(); // Pop the current node from the priority queue

        if (current == end) break; // If the current node is the destination, exit the loop

        for (const auto& [neighbor, weight] : grph[current]) { // Iterate over neighbors of the current node
            int alternate = dist[current] + weight; // Calculate the alternative distance
            if (alternate < dist[neighbor]) { // If the alternative distance is less than the current distance
                dist[neighbor] = alternate; // Update the distance to the neighbor
                previous[neighbor] = current; // Update the previous node for the neighbor
                pq.push({alternate, neighbor}); // Push the neighbor to the priority queue
            }
        }
    }

    vector<int> path; // Initialize the path vector
    for (int at = end; at != -1; at = previous[at]) { // Traverse the previous nodes to reconstruct the path
        path.push_back(at); // Add the current node to the path
    }
    reverse(path.begin(), path.end()); // Reverse the path vector

    if (dist[end] == MAX_INT) { // If the distance to the end node is still maximum
        return {0, {}}; // Return an empty path with cost 0
    }
    return {dist[end], path}; // Return the minimum distance and the shortest path
}

vector<P> yenKShortestPaths(const G& graph, int start, int end, int count) { // Function to find K shortest paths
    vector<P> shortest; // Initialize vector to store shortest paths
    auto [baseCost, basePath] = djks(graph, start, end); // Find the base shortest path
    if (basePath.empty()) return {}; // If no path found, return an empty vector

    shortest.emplace_back(baseCost, basePath); // Add the base shortest path to the vector

    set<pair<int, vector<int>>> candidates; // Set to store candidate paths

    for (int i = 1; i < count; ++i) { // Iterate to find K shortest paths
        if (shortest.size() < i) break; // If no more paths available, exit loop

        int length = shortest[i-1].vertices.size(); // Get the length of the previous shortest path
        for (int j = 0; j < length - 1; ++j) { // Iterate over vertices of the previous shortest path
            int spurNode = shortest[i-1].vertices[j]; // Get the spur node from the previous shortest path
            vector<int> rootPath(shortest[i-1].vertices.begin(), shortest[i-1].vertices.begin() + j + 1); // Create the root path

            int rootPathCost = 0; // Initialize the cost of the root path
            for (int p = 1; p < rootPath.size(); p++) { // Calculate the cost of the root path
                int u = rootPath[p - 1], v = rootPath[p]; // Get the vertices of the edge
                auto it = find_if(graph[u].begin(), graph[u].end(), [v](const pair<int, int>& edge){ return edge.first == v; }); // Find the edge
                if (it != graph[u].end()) { // If the edge exists
                    rootPathCost += it->second; // Add the weight to the root path cost
                }
            }

            G tempGraph = graph; // Create a temporary graph
            for (const auto& p : shortest) { // Iterate over previous shortest paths
                if (p.vertices.size() > j && equal(rootPath.begin(), rootPath.end(), p.vertices.begin())) { // If the root path is a prefix of a previous path
                    int u = p.vertices[j], v = p.vertices[j + 1]; // Get the vertices of the edge to remove
                    tempGraph[u].erase(remove_if(tempGraph[u].begin(), tempGraph[u].end(),
                        [v](const pair<int, int>& edge) { return edge.first == v; }), tempGraph[u].end()); // Remove the edge
                }
            }

            auto [spurCost, spurPath] = djks(tempGraph, spurNode, end); // Find the spur path
            if (!spurPath.empty() && spurPath.front() == spurNode) { // If the spur path is valid
                vector<int> totalPath = rootPath; // Create the total path by concatenating the root and spur paths
                totalPath.insert(totalPath.end(), spurPath.begin() + 1, spurPath.end()); // Insert the spur path after the root path
                int totalCost = rootPathCost + spurCost; // Calculate the total cost of the total path
                candidates.insert({totalCost, totalPath}); // Add the total path to the candidates set
            }
        }

        if (candidates.empty()) break; // If no more candidates available, exit loop
        shortest.emplace_back(candidates.begin()->first, candidates.begin()->second); // Add the shortest candidate path to the vector
        candidates.erase(candidates.begin()); // Remove the shortest candidate path from the set
    }

    return shortest; // Return the vector of K shortest paths
}

int main(int argc, char** argv) { // Main function
    MPI_Init(&argc, &argv); // Initialize MPI
    int rank, size; // Variables to store rank and size
    MPI_Comm_rank(MPI_COMM_WORLD, &rank); // Get the rank of the current process
    MPI_Comm_size(MPI_COMM_WORLD, &size); // Get the total number of processes

    G graph; // Graph data structure
    int num_nodes = 0; // Variable to store the number of nodes
 
    if (rank == 0) { // If master process
        ifstream file("Email-Enron.txt"); // Open input file
        string line; // Variable to store each line of the file
        while (getline(file, line)) { // Read each line of the file
            if (line[0] == '#' || line.empty()) continue; // Skip comments and empty lines
            istringstream iss(line); // Create a string stream from the line
            int u, v; // Variables to store node indices
            while (iss >> u >> v) { // Read node indices from the line
                int n = max(u, v) + 1; // Calculate the maximum node index
                if (n > graph.size()) graph.resize(n); // Resize the graph if necessary
                graph[u].emplace_back(v, 1); // Add edge from u to v
                graph[v].emplace_back(u, 1); // Add edge from v to u (assuming undirected graph)
            }
        }
        num_nodes = graph.size(); // Update the number of nodes
        file.close(); // Close the input file
    }
    MPI_Bcast(&num_nodes, 1, MPI_INT, 0, MPI_COMM_WORLD); // Broadcast the number of nodes to all processes
    graph.resize(num_nodes); // Resize the graph to accommodate the number of nodes
    if (rank == 0) { // If master process
        for (int i = 0; i < num_nodes; ++i) { // Iterate over nodes
            int num_edges = graph[i].size(); // Get the number of edges for the current node
            MPI_Bcast(&num_edges, 1, MPI_INT, 0, MPI_COMM_WORLD); // Broadcast the number of edges to all processes
            for (auto& edge : graph[i]) { // Iterate over edges of the current node
                int details[2] = {edge.first, edge.second}; // Create an array to store edge details
                MPI_Bcast(details, 2, MPI_INT, 0, MPI_COMM_WORLD); // Broadcast edge details to all processes
            }
        }
    } else { // If worker process
        for (int i = 0; i < num_nodes; ++i) { // Iterate over nodes
            int num_edges; // Variable to store the number of edges
            MPI_Bcast(&num_edges, 1, MPI_INT, 0, MPI_COMM_WORLD); // Receive the number of edges from master
            graph[i].resize(num_edges); // Resize the edges vector for the current node
            for (int j = 0; j < num_edges; ++j) { // Iterate over edges
                int details[2]; // Array to store edge details
                MPI_Bcast(details, 2, MPI_INT, 0, MPI_COMM_WORLD); // Receive edge details from master
                graph[i][j] = make_pair(details[0], details[1]); // Store edge details in the graph
            }
        }
    }
    MPI_Barrier(MPI_COMM_WORLD); // Synchronize all processes
    int count = 6; // Number of shortest paths to find
    srand(time(NULL) + rank * 100); // Seed random number generator with rank-specific offset
    
    double start_time = MPI_Wtime(); // Start time measurement

    for (int i = 0; i < 10; ++i) { // Perform 10 iterations
        if (num_nodes <= 1) { // If there are not enough nodes in the graph
            cerr << "Not enough nodes to form a path" << endl; // Print error message
            MPI_Abort(MPI_COMM_WORLD, 1); // Abort MPI execution
        }
        int start = rand() % num_nodes; // Generate random start node index
        int end; // Variable to store the end node index
        do { // Loop until a valid end node is found
            end = rand() % num_nodes; // Generate random end node index
        } while (start == end); // Ensure start and end nodes are different
        vector<P> paths = yenKShortestPaths(graph, start, end, count); // Find K shortest paths from start to end

        #pragma omp critical // OpenMP critical section to ensure thread safety
        {
            cout << "Rank " << rank << " found paths from " << start << " to " << end << ":" << endl; // Print rank and path details
            for (auto& p : paths) { // Iterate over found paths
                cout << "Cost: " << p.cost << " Path: "; // Print path cost
                for (int v : p.vertices) cout << v << " "; // Print path vertices
                cout << endl; // Move to the next line
            }
        }
    }
    
    double end_time = MPI_Wtime(); // End time measurement
    double execution_time = end_time - start_time; // Calculate execution time
    
      if (rank == 0) {
        cout << "Execution time: " << execution_time << " seconds" << endl; // Print execution time
    }

    MPI_Finalize(); 
    return 0; 
}
